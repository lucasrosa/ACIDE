/**** Amigos [podem filar!] ****/

public class MyBoatExample{ 

    public static void main(String[] args)
    {
        System.out.print("Hello World!");
    }
}
dsadasd


N˜ão apaporra do meu nome
que'é
asdas